import * as http from "http";
import * as fs from "fs";
import * as path from "path";
import * as ts from "typescript";
import { Bill, ErrorResponse, calculateBill, calculateSummary, isValidServiceNo, isValidUnits } from "./billing";

const PORT = Number(process.env.PORT) || 3000;
const DATA_FILE = path.join(__dirname, "..", "data", "readings.json");
const CLIENT_FILE = path.join(__dirname, "client.ts");

const STYLE = `body { 
      font-family: Arial;
      background: #eeeeee;
      width: 450px;
      margin: 20px auto; }
      h1 { text-align: center;
      }
.box { 
      background: white;
      padding: 15px; 
      margin-bottom: 15px;
      border: 1px solid #cccccc;
      }
input { 
      width: 100%; 
      padding: 8px;
      margin: 5px 0 10px 0;
      box-sizing: border-box;
      }
button {
      width: 100%;
      padding: 10px;
      margin-top: 8px;
      }
table { 
      width: 100%; 
      border-collapse: collapse; 
      margin-top: 8px;
      }
th, td { 
      border: 1px solid #cccccc;
      padding: 5px;
      text-align: left;
      }
.error { 
      background: #ffdddd; 
      padding: 8px; 
      margin-bottom: 8px; 
      }
.warning {
      background: #ffffcc; 
      padding: 8px;
      margin-bottom: 8px; 
      }
.success {
      background: #ddffdd;
      padding: 8px;
      margin-bottom: 8px;
      }
.total td { 
      font-weight: bold;
      }
.small { 
      color: gray; 
      font-size: 13px; 
      }
`;

const PAGE = `<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>EB Bill System</title>
<style>
${STYLE}</style>
</head>
<body>
<h1>EB Bill System</h1>
<div class="box">
  Service number (9 to 12 digits)
  <input id="serviceNo" maxlength="12">
  Units consumed
  <input id="units" type="number" min="0">
  <button id="calcBtn">Calculate bill</button>
  <button id="clearBtn">Clear</button>
</div>
<div class="box" id="result">
  <span class="small">Your bill will appear here.</span>
</div>
<div class="box">
  <button id="summaryBtn">View Summary</button>
</div>
<div class="box">
  <b>Already read service numbers</b>
  <div id="history"></div>
</div>
<script type="module" src="/client.js"></script>
</body>
</html>`;

const SUMMARY_PAGE = `<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>EB Bill Summary</title>
<style>
${STYLE}</style>
</head>
<body>
<h1>Summary</h1>
<div class="box">
  <div id="summary"></div>
</div>
<div class="box">
  <button id="clearAllBtn">Clear all readings</button>
  <button id="backBtn">Back to calculation</button>
</div>
<script type="module" src="/client.js"></script>
</body>
</html>`;

const readings: Record<string, Bill> = fs.existsSync(DATA_FILE)
  ? JSON.parse(fs.readFileSync(DATA_FILE, "utf-8"))
  : {};

function saveReadings() {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  fs.writeFileSync(DATA_FILE, JSON.stringify(readings, null, 2));
}

function getClientScript(): string {
  const source = fs.readFileSync(CLIENT_FILE, "utf-8");
  return ts.transpileModule(source, {
    compilerOptions: { target: ts.ScriptTarget.ES2020, module: ts.ModuleKind.ES2020 },
  }).outputText;
}

function sendJson(res: http.ServerResponse, status: number, data: unknown) {
  res.writeHead(status, { "Content-Type": "application/json" });
  res.end(JSON.stringify(data));
}

function sendError(res: http.ServerResponse, status: number, message: string) {
  const body: ErrorResponse = { error: message };
  sendJson(res, status, body);
}

function readBody(req: http.IncomingMessage): Promise<string> {
  return new Promise((resolve) => {
    let body = "";
    req.on("data", (chunk) => (body += chunk));
    req.on("end", () => resolve(body));
  });
}

async function addReading(req: http.IncomingMessage, res: http.ServerResponse) {
  let input: { serviceNo?: unknown; units?: unknown };
  try {
    input = JSON.parse(await readBody(req));
  } catch {
    return sendError(res, 400, "Invalid request.");
  }

  const serviceNo = String(input.serviceNo || "").trim();
  const units = input.units;

  if (!isValidServiceNo(serviceNo)) {
    return sendError(res, 400, "Service number must be 9 to 12 digits.");
  }
  if (!isValidUnits(units)) {
    return sendError(res, 400, "Units must be a whole number (0 or more).");
  }

  if (readings[serviceNo]) {
    const body: ErrorResponse = {
      alreadyRead: true,
      error: `Service number ${serviceNo} is already read. It cannot be entered twice.`,
      existing: readings[serviceNo],
    };
    return sendJson(res, 409, body);
  }

  const { lines, total, slab } = calculateBill(units);
  const bill: Bill = { serviceNo, units, lines, total, slab, readAt: new Date().toISOString() };
  readings[serviceNo] = bill;
  saveReadings();
  sendJson(res, 201, bill);
}

const server = http.createServer(async (req, res) => {
  const { method, url } = req;

  if (method === "GET" && url === "/") {
    res.writeHead(200, { "Content-Type": "text/html" });
    res.end(PAGE);
  } else if (method === "GET" && url === "/summary") {
    res.writeHead(200, { "Content-Type": "text/html" });
    res.end(SUMMARY_PAGE);
  } else if (method === "GET" && url === "/client.js") {
    res.writeHead(200, { "Content-Type": "text/javascript" });
    res.end(getClientScript());
  } else if (method === "GET" && url === "/api/bills") {
    sendJson(res, 200, Object.values(readings).reverse());
  } else if (method === "GET" && url === "/api/summary") {
    sendJson(res, 200, calculateSummary(Object.values(readings)));
  } else if (method === "DELETE" && url === "/api/bills") {
    for (const serviceNo in readings) delete readings[serviceNo];
    saveReadings();
    sendJson(res, 200, { cleared: true });
  } else if (method === "POST" && url === "/api/bills") {
    await addReading(req, res);
  } else {
    sendError(res, 404, "Not found.");
  }
});

server.listen(PORT, () => {
  console.log(`EB Bill System running at http://localhost:${PORT}`);
});
