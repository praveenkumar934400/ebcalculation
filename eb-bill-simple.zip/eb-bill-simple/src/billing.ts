export type BillLing = {
  label: string;
  units: number;
  rate: number;
  amount: number;
};

export type Bill = {
  serviceNo: string;
  units: number;
  lines: BillLing[];
  total: number;
  slab: "Slab 1" | "Slab 2";
  readAt: string;
};

export type Summary = {
  count: number;
  totalUnits: number;
  totalAmount: number;
  averageAmount: number;
  highestServiceNo: string | null;
  highestAmount: number;
  slabGroups: { name: string; count: number; units: number; amount: number }[];
  tariffSlabs: { label: string; rate: number; units: number; amount: number }[];
};

export type ErrorResponse = {
  error : string;
  alreadyRead?: boolean;
  existing?: Bill;
};

const pricelist = [
  {label:"1-200 units",size:200,rate:0},
  {label:"201-300 units",size:100,rate:4},  
  {label:"301-400 units",size:100,rate:4.75},
  {label:"401-500 units",size:100,rate:5.5},
  {label:"above 500 units",size:Infinity,rate:7},
];

export function calculateBill(units:number) {
  const lines:BillLing[] = [];
  let total = 0;
  let unitsLeft = units;

  for (const slab of pricelist) {
    if (unitsLeft <= 0) 
    break;
    const unitsInSlab = Math.min(unitsLeft, slab.size);
    const amount = unitsInSlab * slab.rate;
    lines.push({ label: slab.label, units: unitsInSlab, rate: slab.rate, amount });
    total += amount;
    unitsLeft -= unitsInSlab;
  }

  const slab = units <= 500 ? "Slab 1" : "Slab 2";
  return { lines, total, slab } as const;
}

export function calculateSummary(bills: Bill[]): Summary {
  const slab1 = { name: "Slab 1 (up to 500 units)", count: 0, units: 0, amount: 0 };
  const slab2 = { name: "Slab 2 (above 500 units)", count: 0, units: 0, amount: 0 };
  const tariffSlabs = pricelist.map((t) => ({ label: t.label, rate: t.rate, units: 0, amount: 0 }));

  let totalUnits = 0;
  let totalAmount = 0;
  let highestBill: Bill | null = null;

  for (const bill of bills) {
    totalUnits += bill.units;
    totalAmount += bill.total;

    const group = bill.slab === "Slab 1" ? slab1 : slab2;
    group.count++;
    group.units += bill.units;
    group.amount += bill.total;

    bill.lines.forEach((line, i) => {
      tariffSlabs[i].units += line.units;
      tariffSlabs[i].amount += line.amount;
    });

    if (!highestBill || bill.total > highestBill.total) highestBill = bill;
  }

  return {
    count: bills.length,
    totalUnits,
    totalAmount,
    averageAmount: bills.length ? totalAmount / bills.length : 0,
    highestServiceNo: highestBill ? highestBill.serviceNo : null,
    highestAmount: highestBill ? highestBill.total : 0,
    slabGroups: [slab1, slab2],
    tariffSlabs,
  };
}

export function isValidServiceNo(serviceNo: string): boolean {
  return /^\d{9,12}$/.test(serviceNo);
}

export function isValidUnits(units: unknown): units is number {
  return typeof units === "number" && Number.isInteger(units) && units >= 0;
} 
