import type { Bill, ErrorResponse, Summary } from "./billing";

const serviceInput = document.getElementById("serviceNo") as HTMLInputElement;
const unitsInput = document.getElementById("units") as HTMLInputElement;
const calcButton = document.getElementById("calcBtn") as HTMLButtonElement;
const clearButton = document.getElementById("clearBtn") as HTMLButtonElement;
const resultBox = document.getElementById("result") as HTMLDivElement;
const historyBox = document.getElementById("history") as HTMLDivElement;
const summaryBox = document.getElementById("summary") as HTMLDivElement;

function rupees(amount: number): string {
  return "₹" + amount.toFixed(2);
}

function messageHtml(type: "error" | "warning" | "success", text: string): string {
  const box = document.createElement("div");
  box.className = type;
  box.textContent = text;
  return box.outerHTML;
}

function billHtml(bill: Bill): string {
  const rows = bill.lines
    .map((l) => `<tr><td>${l.label}</td><td>${l.units}</td><td>${l.rate}</td><td>${rupees(l.amount)}</td></tr>`)
    .join("");

  return `
    <p class="small">Service no: ${bill.serviceNo} | ${bill.units} units | ${bill.slab}</p>
    <table>
      <tr><th>Slab</th><th>Units</th><th>Rate</th><th>Amount</th></tr>
      ${rows}
      <tr class="total"><td colspan="3">Total</td><td>${rupees(bill.total)}</td></tr>
    </table>`;
}

async function loadHistory() {
  const response = await fetch("/api/bills");
  const bills: Bill[] = await response.json();

  if (bills.length === 0) {
    historyBox.innerHTML = `<p class="small">Nothing yet.</p>`;
    return;
  }

  const rows = bills
    .map((b) => `<tr><td>${b.serviceNo}</td><td>${b.units}</td><td>${b.slab}</td><td>${rupees(b.total)}</td></tr>`)
    .join("");

  historyBox.innerHTML = `
    <table>
      <tr>
      <th>Service no</th>
      <th>Units</th>
      <th>Slab</th>
      <th>Total</th>
      </tr>
      ${rows}
    </table>`;
}

async function loadSummary() {
  const response = await fetch("/api/summary");
  const s: Summary = await response.json();

  if (s.count === 0) {
    summaryBox.innerHTML = `<p class="small">No readings yet.</p>`;
    return;
  }

  const groupRows = s.slabGroups
    .map((g) => `<tr>
                  <td>${g.name}</td>
                  <td>${g.count}</td>
                  <td>${g.units}</td>
                  <td>${rupees(g.amount)}</td>
                  </tr>`)
    .join("");

  const tariffRows = s.tariffSlabs
                  .map((t) => `<tr>
                  <td>${t.label}</td>
                  <td>${t.rate}</td>
                  <td>${t.units}</td>
                  <td>${rupees(t.amount)}</td>
                  </tr>`)
    .join("");

  summaryBox.innerHTML = `
    <table>
      <tr>
      <td>Service numbers read</td>
      <td>${s.count}</td>
      </tr>
      <tr>
      <td>Total units</td>
      <td>${s.totalUnits}</td>
      </tr>
      <tr>
      <td>Total amount</td>
      <td>${rupees(s.totalAmount)}</td>
      </tr>
      <tr>
      <td>Average bill</td>
      <td>${rupees(s.averageAmount)}</td>
      </tr>
      <tr>
      <td>Highest bill</td>
      <td>${rupees(s.highestAmount)} (${s.highestServiceNo})</td>
      </tr>
      </table>
      <p class="small">By slab</p>
      <table>
      <tr><th>Slab</th><th>Bills</th><th>Units</th><th>Amount</th></tr>
      ${groupRows}
    </table>
    <p class="small">By tariff slab</p>
    <table>
      <tr><th>Slab</th><th>Rate</th><th>Units</th><th>Amount</th></tr>
      ${tariffRows}
    </table>`;
}

async function submitReading(serviceNo: string, units: number) {
  const response = await fetch("/api/bills", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ serviceNo, units }),
  });
  const data = await response.json();

  if (response.ok) {
    resultBox.innerHTML = messageHtml("success", "Reading saved.") + billHtml(data as Bill);
    loadHistory();
    return;
  }

  const err = data as ErrorResponse;
  if (err.alreadyRead && err.existing) {
    resultBox.innerHTML =
      messageHtml("warning", err.error) + `<p class="small">Earlier bill:</p>` + billHtml(err.existing);
  } else {
    resultBox.innerHTML = messageHtml("error", err.error);
  }
}

const onSummaryPage = location.pathname === "/summary";

if (onSummaryPage) {
  const backButton = document.getElementById("backBtn") as HTMLButtonElement;
  backButton.addEventListener("click", () => {
    location.href = "/";
  });
  const clearAllButton = document.getElementById("clearAllBtn") as HTMLButtonElement;
  clearAllButton.addEventListener("click", async () => {
    if (!confirm("Delete all saved readings? This cannot be undone.")) return;
    await fetch("/api/bills", { method: "DELETE" });
    loadSummary();
  });
  loadSummary();
} else {
  const summaryButton = document.getElementById("summaryBtn") as HTMLButtonElement;
  summaryButton.addEventListener("click", () => {
    location.href = "/summary";
  });

  calcButton.addEventListener("click", async () => {
    const serviceNo = serviceInput.value.trim();
    const units = Number(unitsInput.value);

    if (!/^\d{9,12}$/.test(serviceNo)) {
      resultBox.innerHTML = messageHtml("error", "Service number must be 9 to 12 digits.");
      return;
    }
    if (unitsInput.value === "" || !Number.isInteger(units) || units < 0) {
      resultBox.innerHTML = messageHtml("error", "Units must be a whole number (0 or more).");
      return;
    }

    calcButton.disabled = true;
    try {
      await submitReading(serviceNo, units);
    } catch {
      resultBox.innerHTML = messageHtml("error", "Cannot reach the server.");
    }
    calcButton.disabled = false;
  });

  clearButton.addEventListener("click", () => {
    serviceInput.value = "";
    unitsInput.value = "";
    resultBox.innerHTML = `<span class="small">Your bill will appear here.</span>`;
    serviceInput.focus();
  });

  serviceInput.addEventListener("input", () => {
    serviceInput.value = serviceInput.value.replace(/\D/g, "");
  });

  loadHistory();
}
